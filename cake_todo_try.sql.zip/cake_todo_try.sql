-- phpMyAdmin SQL Dump
-- version 4.6.5.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: 2018 年 1 月 30 日 18:34
-- サーバのバージョン： 5.6.34
-- PHP Version: 5.6.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cake_todo_try`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `name` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `body` text COLLATE utf8_unicode_ci NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `due_date` date DEFAULT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `tasks`
--

INSERT INTO `tasks` (`id`, `name`, `body`, `status`, `due_date`, `created`, `modified`) VALUES
(1, 'たまごを買う', 'たまごがないのでたまごを買う', 1, NULL, '2018-01-30 04:06:49', '2018-01-30 17:36:58'),
(2, '小麦粉の購入', '薄力粉を買う', 0, NULL, '2018-01-30 05:46:15', '2018-01-30 05:46:15'),
(3, '時間', '時間を確認', 0, NULL, '2018-01-30 05:47:05', '2018-01-30 05:47:05'),
(4, '時間を確認', '時間を確認', 0, NULL, '2018-01-30 13:50:22', '2018-01-30 13:50:22'),
(5, '超重要タスク', '', 0, NULL, '2018-01-30 18:07:35', '2018-01-30 18:07:35'),
(6, 'リダイレクトをsetFlashに変更', '', 1, NULL, '2018-01-30 18:12:12', '2018-01-30 18:26:28'),
(7, 'リダイレクト', '', 1, NULL, '2018-01-30 18:16:12', '2018-01-30 18:26:40'),
(8, 'テスト', '', 0, NULL, '2018-01-30 18:22:01', '2018-01-30 18:22:01'),
(9, 'テスト', '', 0, NULL, '2018-01-30 18:24:28', '2018-01-30 18:24:28'),
(10, 'テスト', '', 1, NULL, '2018-01-30 18:24:42', '2018-01-30 18:26:25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
